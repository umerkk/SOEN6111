package com.pokemon.Card;

public class CardFactory {
	
	public Card createCard(String name, Card.Type type, int i) {
		if (1 == i) {
			if (type == Card.Type.pokemon)
				return new Pokemon("/deck1/" + name + ".png");

			if (type == Card.Type.energy)
				return new Energy("/deck1/" + name + ".png", String.valueOf(name.charAt(0)).toLowerCase());

			return new Card("/deck1/" + name + ".png", type);
		}
		
		else {
			if (type == Card.Type.pokemon)
				return new Pokemon("/deck2/" + name + ".png");

			if (type == Card.Type.energy)
				return new Energy("/deck2/" + name + ".png", String.valueOf(name.charAt(0)).toLowerCase());

			return new Card("/deck2/" + name + ".png", type);
		}

	}

}
