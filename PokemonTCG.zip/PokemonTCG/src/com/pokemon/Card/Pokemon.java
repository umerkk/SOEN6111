package com.pokemon.Card;

import java.awt.Graphics;
import java.util.ArrayList;

public class Pokemon extends Card{
	private ArrayList<Energy> energys;
	//private boolean isBench;
	
	
	
	
	public Pokemon(String url){
		super(url, Card.Type.pokemon);
		this.energys = new ArrayList<Energy>();
	}
	
	
	public void addEnergy(Energy e){
		this.energys.add(e);
		
		
		Graphics g2d = this.cardImage.getGraphics();
		g2d.drawImage(e.getIcon(), 50 * (energys.size() - 1), 342, 50, 50, null);
		
		
	}
	
	
//	public void setBench(boolean b){
//		this.isBench = b;
//	}
//	
//	public boolean getBench(){
//		return isBench;
//	}
//	
	
	
	
	
	
	
	
	
}
