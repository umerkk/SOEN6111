package com.pokemon.Card;

import java.awt.image.BufferedImage;

import com.pokemon.Main.ImageLoader;

public class Energy extends Card{
	private BufferedImage icon;
	private String name;
	
	
	public Energy(String url, String name){
		super(url, Card.Type.energy);	
		this.name = name;
		ImageLoader loader = new ImageLoader();
		this.icon = loader.load("/" + name.toLowerCase() + "Icon.png");
	}
	
	public BufferedImage getIcon(){
		return icon;
	}
	
}
